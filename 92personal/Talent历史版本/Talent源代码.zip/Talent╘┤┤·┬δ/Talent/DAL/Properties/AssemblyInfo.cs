﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("数据访问层-Maticsoft.Net.SystemFramework")]
[assembly: AssemblyDescription("Maticsoft.Net.SystemFramework示例项目源码")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("李天平")]
[assembly: AssemblyProduct("http://www.maticsoft.com")]
[assembly: AssemblyCopyright("Copyright (C)Maticsoft 2004-2010")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("2.0.0.0")]
[assembly: AssemblyFileVersion("2.0.0.0")]
