﻿using System;
namespace Talent.Model
{
	/// <summary>
	/// TB_RC_TalentDocument:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class TB_RC_TalentDocument
	{
		public TB_RC_TalentDocument()
		{}
		#region Model
		private int _td_no;
		private int? _td_cb_no;
		private int? _td_ti_no;
		private string _td_docname;
		private string _td_docpath;
		private string _td_createper;
		private DateTime? _td_createdate;
		/// <summary>
		/// 
		/// </summary>
		public int TD_No
		{
			set{ _td_no=value;}
			get{return _td_no;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? TD_CB_No
		{
			set{ _td_cb_no=value;}
			get{return _td_cb_no;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? TD_TI_No
		{
			set{ _td_ti_no=value;}
			get{return _td_ti_no;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string TD_DocName
		{
			set{ _td_docname=value;}
			get{return _td_docname;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string TD_docPath
		{
			set{ _td_docpath=value;}
			get{return _td_docpath;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string TD_CreatePer
		{
			set{ _td_createper=value;}
			get{return _td_createper;}
		}
		/// <summary>
		/// 
		/// </summary>
		public DateTime? TD_CreateDate
		{
			set{ _td_createdate=value;}
			get{return _td_createdate;}
		}
		#endregion Model

	}
}

