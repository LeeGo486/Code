﻿using System;
using System.Data;
using System.Collections.Generic;
using Maticsoft.Common;
using Talent.Model;
namespace Talent.BLL
{
	/// <summary>
	/// TB_RC_CompanyTalentClassRelate
	/// </summary>
	public partial class TB_RC_CompanyTalentClassRelate
	{
		private readonly Talent.DAL.TB_RC_CompanyTalentClassRelate dal=new Talent.DAL.TB_RC_CompanyTalentClassRelate();
		public TB_RC_CompanyTalentClassRelate()
		{}
		#region  Method

        public bool Exists(Talent.Model.TB_RC_CompanyTalentClassRelate model)
        {
            return dal.Exists(model);
        }
		/// <summary>
		/// 增加一条数据
		/// </summary>
		public bool Add(Talent.Model.TB_RC_CompanyTalentClassRelate model)
		{
			return dal.Add(model);
		}

		/// <summary>
		/// 删除一条数据
		/// </summary>
		public bool Delete(int CT_CB_No)
		{
			
			return dal.Delete(CT_CB_No);
		}

		#endregion  Method
	}
}

